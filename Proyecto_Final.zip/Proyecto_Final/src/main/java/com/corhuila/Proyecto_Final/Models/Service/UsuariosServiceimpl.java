package com.corhuila.Proyecto_Final.Models.Service;

import com.corhuila.Proyecto_Final.Models.Entity.Usuario;
import com.corhuila.Proyecto_Final.Models.Repository.IUsuariosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UsuariosServiceimpl implements IUsuariosService {

    @Autowired
    private IUsuariosRepository IUsuariosRepository;
    @Override
    @Transactional(readOnly = true)
    public List<Usuario> findAll(){return (List<Usuario>) IUsuariosRepository.findAll();}

    @Override
    @Transactional(readOnly = true)
    public Usuario findById(Long id) { return IUsuariosRepository.findById(id).orElse(null);}

    @Override
    @Transactional(readOnly = true)
    public Usuario save(Usuario usuario){return IUsuariosRepository.save(usuario);}

    @Override
    @Transactional(readOnly = true)
    public void delete(Long id){
        IUsuariosRepository.deleteById(id);}

}
