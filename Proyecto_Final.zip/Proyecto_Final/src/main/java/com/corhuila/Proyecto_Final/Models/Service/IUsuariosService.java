package com.corhuila.Proyecto_Final.Models.Service;

import com.corhuila.Proyecto_Final.Models.Entity.Usuario;

import java.util.List;

public interface IUsuariosService {
    public List<Usuario> findAll();
    public Usuario findById(Long id);
    public Usuario save(Usuario usuario);
    public void delete(Long id);
}
