package com.corhuila.Proyecto_Final.Models.Repository;

import com.corhuila.Proyecto_Final.Models.Entity.Usuario;
import org.springframework.data.repository.CrudRepository;

//Comunica y estblece la relacion entre la entidad y el servicio.
public interface IUsuariosRepository extends CrudRepository<Usuario,Long> {
}
