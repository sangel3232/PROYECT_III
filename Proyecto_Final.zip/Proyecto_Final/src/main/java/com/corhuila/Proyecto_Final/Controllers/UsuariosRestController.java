package com.corhuila.Proyecto_Final.Controllers;


import com.corhuila.Proyecto_Final.Models.Entity.Usuario;
import com.corhuila.Proyecto_Final.Models.Service.IUsuariosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("/api")
public class UsuariosRestController {
    @Autowired
    private IUsuariosService usuariosService;

    @GetMapping("/usuarios")
    public List<Usuario> index(){
        return usuariosService.findAll();}

    //Método para Listar
    @GetMapping("/usuarios/{id}")
    public Usuario show(@PathVariable Long id){
        return usuariosService.findById(id);}

    //Método para crear el usuario
    @PostMapping("/usuarios")
    @ResponseStatus(HttpStatus.CREATED)
    public Usuario create(@RequestBody Usuario usuario){
        return usuariosService.save(usuario);}

    //Método para Actualizar el usuario por Id
    @PutMapping("/usuarios/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public Usuario update(@RequestBody Usuario usuario, @PathVariable Long id){
        Usuario usuarioActual = usuariosService.findById(id);
        usuarioActual.setNombre(usuario.getNombre());
        usuarioActual.setEmail(usuario.getEmail());
        usuarioActual.setRol(usuario.getRol());

        return usuariosService.save(usuarioActual);}

    //Método para eliminar el usuario por Id
    @DeleteMapping("/usuario/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id){
        usuariosService.delete(id);}

    }






