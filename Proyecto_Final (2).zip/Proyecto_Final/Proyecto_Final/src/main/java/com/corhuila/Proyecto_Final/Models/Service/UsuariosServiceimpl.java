package com.corhuila.Proyecto_Final.Models.Service;

import com.corhuila.Proyecto_Final.Models.Entity.Usuario;
import com.corhuila.Proyecto_Final.Models.Repository.IUsuariosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuariosServiceimpl implements IUsuariosService {

    @Autowired
    private IUsuariosRepository usuariosRepository;

    @Override
    public List<Usuario> findAll(){return (List<Usuario>) usuariosRepository.findAll();}

    @Override
    public Optional<Usuario> findById(Long id) { return usuariosRepository.findById(id);}

    @Override
    public Usuario save(Usuario usuario){return usuariosRepository.save(usuario);}

    @Override
    public void update(Usuario usuario, Long id){
        Optional<Usuario> us = usuariosRepository.findById(id);

        if(!us.isEmpty()){
            Usuario usuarioUpdate = us.get();
            usuarioUpdate.setNombre(usuario.getNombre());
            usuarioUpdate.setEmail(usuario.getEmail());
            usuarioUpdate.setRol(usuario.getRol());

            usuariosRepository.save(usuarioUpdate);
        }else{
            System.out.println("No existe el usuario");
        }
    }
    @Override
    public void delete(Long id){
        usuariosRepository.deleteById(id);}

}
