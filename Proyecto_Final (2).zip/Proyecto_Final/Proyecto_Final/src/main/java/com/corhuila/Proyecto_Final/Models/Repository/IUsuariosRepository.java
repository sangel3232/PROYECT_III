package com.corhuila.Proyecto_Final.Models.Repository;

import com.corhuila.Proyecto_Final.Models.Entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//Comunica y establece la relacion entre la entidad y el servicio.
@Repository
public interface IUsuariosRepository extends JpaRepository<Usuario, Long> {
}
