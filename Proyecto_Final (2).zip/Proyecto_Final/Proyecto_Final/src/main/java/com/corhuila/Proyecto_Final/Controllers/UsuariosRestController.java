package com.corhuila.Proyecto_Final.Controllers;


import com.corhuila.Proyecto_Final.Models.Entity.Usuario;
import com.corhuila.Proyecto_Final.Models.Service.IUsuariosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("/api")
public class UsuariosRestController {

    @Autowired
    private IUsuariosService usuariosService;

    @GetMapping("/usuarios")
    public List<Usuario> findAll(){
        return usuariosService.findAll();}

    //Método para Listar
    @GetMapping("/usuarios/{id}")
    public Optional<Usuario> findById(@PathVariable Long id){
        return usuariosService.findById(id);}

    //Método para crear el usuario
    @PostMapping("/usuarios")
    public Usuario save(@RequestBody Usuario usuario){
        return usuariosService.save(usuario);}

    //Método para Actualizar el usuario por Id
    @PutMapping("/usuarios/{id}")
    public void update(@RequestBody Usuario usuario, @PathVariable Long id){
        usuariosService.update(usuario, id);
    }

    //Método para eliminar el usuario por Id
    @DeleteMapping("/usuario/{id}")
    public void delete(@PathVariable Long id){
        usuariosService.delete(id);}
    }






