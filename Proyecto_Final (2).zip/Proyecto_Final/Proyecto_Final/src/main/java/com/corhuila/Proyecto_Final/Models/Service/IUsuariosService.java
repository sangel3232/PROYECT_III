package com.corhuila.Proyecto_Final.Models.Service;

import com.corhuila.Proyecto_Final.Models.Entity.Usuario;

import java.util.List;
import java.util.Optional;

public interface IUsuariosService {
    List<Usuario> findAll();
    Optional<Usuario> findById(Long id);
    Usuario save(Usuario usuario);
    void update(Usuario usuario, Long id);
    void delete(Long id);
}
